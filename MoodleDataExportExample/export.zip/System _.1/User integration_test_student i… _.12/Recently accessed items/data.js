var data_file_8 = {
    "1": {
        "course_name": "completableWorld",
        "module_name": "resource",
        "timeaccess": "Tuesday, 18 March 2025, 3:49 PM"
    },
    "2": {
        "course_name": "completableWorld",
        "module_name": "resource",
        "timeaccess": "Tuesday, 18 March 2025, 3:49 PM"
    }
}