var data_file_18 = {
    "0": {
        "subject": "New sign in to your New Site account",
        "fullmessage": "Hi integration_test_student integration_test_student,\n\nYour New Site account was just signed in to from a new device.\n\n\t* Your account: integration_test_student\nintegration_test_student@example.local\n\t* Tuesday, 18 March 2025, 3:49 PM\n\t* Device: Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36\n(KHTML, like Gecko) Chrome\/133.0.6943.16 Safari\/537.36\n\t* IP: 172.18.0.1\n\nIf this was you, then you don't need to do anything.\n\nIf you don't recognise this activity, please change your password [1].\n\n\nLinks:\n------\n[1] http:\/\/localhost:26875\/login\/change_password.php\n",
        "smallmessage": "Your integration_test_student account was just signed in to from a new device.",
        "component": "moodle",
        "eventtype": "newlogin",
        "contexturl": null,
        "contexturlname": null,
        "timeread": "-",
        "timecreated": "Tuesday, 18 March 2025, 3:51 PM",
        "customdata": "{\"notificationiconurl\":\"http:\\\/\\\/localhost:26875\\\/theme\\\/image.php\\\/boost\\\/core\\\/1742311535\\\/u\\\/f1\",\"courseid\":\"1\"}"
    },
    "1": {
        "subject": "New sign in to your New Site account",
        "fullmessage": "Hi integration_test_student integration_test_student,\n\nYour New Site account was just signed in to from a new device.\n\n\t* Your account: integration_test_student\nintegration_test_student@example.local\n\t* Tuesday, 18 March 2025, 3:49 PM\n\t* Device:\n\t* IP: 172.18.0.1\n\nIf this was you, then you don't need to do anything.\n\nIf you don't recognise this activity, please change your password [1].\n\n\nLinks:\n------\n[1] http:\/\/localhost:26875\/login\/change_password.php\n",
        "smallmessage": "Your integration_test_student account was just signed in to from a new device.",
        "component": "moodle",
        "eventtype": "newlogin",
        "contexturl": null,
        "contexturlname": null,
        "timeread": "-",
        "timecreated": "Tuesday, 18 March 2025, 3:51 PM",
        "customdata": "{\"notificationiconurl\":\"http:\\\/\\\/localhost:26875\\\/theme\\\/image.php\\\/boost\\\/core\\\/1742311535\\\/u\\\/f1\",\"courseid\":\"1\"}"
    },
    "2": {
        "subject": "New sign in to your New Site account",
        "fullmessage": "Hi integration_test_student integration_test_student,\n\nYour New Site account was just signed in to from a new device.\n\n\t* Your account: integration_test_student\nintegration_test_student@example.local\n\t* Tuesday, 18 March 2025, 3:49 PM\n\t* Device:\n\t* IP: 172.18.0.1\n\nIf this was you, then you don't need to do anything.\n\nIf you don't recognise this activity, please change your password [1].\n\n\nLinks:\n------\n[1] http:\/\/localhost:26875\/login\/change_password.php\n",
        "smallmessage": "Your integration_test_student account was just signed in to from a new device.",
        "component": "moodle",
        "eventtype": "newlogin",
        "contexturl": null,
        "contexturlname": null,
        "timeread": "-",
        "timecreated": "Tuesday, 18 March 2025, 3:51 PM",
        "customdata": "{\"notificationiconurl\":\"http:\\\/\\\/localhost:26875\\\/theme\\\/image.php\\\/boost\\\/core\\\/1742311535\\\/u\\\/f1\",\"courseid\":\"1\"}"
    },
    "3": {
        "subject": "Data request: Export all of my personal data",
        "fullmessage": "Dear Admin User,\n\nYou have received a data request:\n\n\t\t TYPE\n\t\t Export all of my personal data\n\n\t\t USER\n\t\t integration_test_student integration_test_student\n\n\t\t REQUESTED BY\n\t\t integration_test_student integration_test_student\n\n\t\t SITE\n\t\t New Site [1]\n\n\t\t COMMENTS\n\n\t\t DATE REQUESTED\n\t\t Monday, 24 March 2025, 4:36 PM\n\n-------------------------\n View the request [2] \n\nLinks:\n------\n[1] http:\/\/localhost:26875\/\n[2] http:\/\/localhost:26875\/admin\/tool\/dataprivacy\/datarequests.php\n",
        "smallmessage": null,
        "component": "tool_dataprivacy",
        "eventtype": "contactdataprotectionofficer",
        "contexturl": "http:\/\/localhost:26875\/admin\/tool\/dataprivacy\/datarequests.php",
        "contexturlname": "Data requests",
        "timeread": "Monday, 24 March 2025, 4:36 PM",
        "timecreated": "Monday, 24 March 2025, 4:36 PM",
        "customdata": null
    }
}