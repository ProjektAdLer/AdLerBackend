var data_file_24 = {
    "block_online_users_uservisibility": {
        "value": "Yes",
        "description": "Online status visible to other users in the Online users block."
    }
}