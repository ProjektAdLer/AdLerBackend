var data_file_6 = {
    "name": "Element 1 1 Point",
    "intro": "<div class=\"no-overflow\"><p style=\"position:relative; background-color:#e6e9ed;\"><\/p><\/div>",
    "completion": {
        "state": "1"
    }
}