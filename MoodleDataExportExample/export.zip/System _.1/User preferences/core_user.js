var data_file_27 = {
    "core_user_welcome": {
        "value": "1742834191",
        "description": "Timestamp logged for when the welcome message was shown to the user for the first time."
    }
}