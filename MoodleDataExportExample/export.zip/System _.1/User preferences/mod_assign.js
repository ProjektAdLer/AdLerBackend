var data_file_22 = {
    "assign_markerfilter": {
        "value": "No",
        "description": "Filter the assign summary by the assigned marker."
    },
    "assign_workflowfilter": {
        "value": "No",
        "description": "Filter by the different workflow stages."
    },
    "assign_quickgrading": {
        "value": "No",
        "description": "A preference as to whether quick grading is used or not."
    },
    "assign_downloadasfolders": {
        "value": "No",
        "description": "A user preference for whether multiple file submissions should be downloaded into folders"
    }
}