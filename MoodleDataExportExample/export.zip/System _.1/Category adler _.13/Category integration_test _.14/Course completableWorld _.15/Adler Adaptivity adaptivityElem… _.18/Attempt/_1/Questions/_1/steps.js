var data_file_3 = {
    "steps": {
        "1": {
            "time": "Tuesday, 18 March 2025, 3:49 PM",
            "action": "Started",
            "mark": "",
            "state": "Not complete"
        },
        "2": {
            "time": "Tuesday, 18 March 2025, 3:49 PM",
            "action": "Submit: Philipp",
            "mark": "1.00",
            "state": "Correct"
        }
    }
}