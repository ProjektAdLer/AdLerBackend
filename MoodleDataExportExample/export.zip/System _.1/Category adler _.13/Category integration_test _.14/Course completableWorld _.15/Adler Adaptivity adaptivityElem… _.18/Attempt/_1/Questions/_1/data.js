var data_file_2 = {
    "name": "Wer ist der coolste",
    "question": "Wer ist der coolste: Filipp; Philipp",
    "answer": "Philipp",
    "timemodified": "Tuesday, 18 March 2025, 3:49 PM",
    "mark": "1.00",
    "flagged": "No",
    "generalfeedback": ""
}