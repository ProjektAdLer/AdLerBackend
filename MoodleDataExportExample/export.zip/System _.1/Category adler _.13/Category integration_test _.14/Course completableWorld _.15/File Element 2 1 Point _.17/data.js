var data_file_7 = {
    "name": "Element 2 1 Point",
    "intro": "<div class=\"no-overflow\"><p style=\"position:relative; background-color:#e6e9ed;\"><\/p><\/div>",
    "completion": {
        "state": "1"
    }
}