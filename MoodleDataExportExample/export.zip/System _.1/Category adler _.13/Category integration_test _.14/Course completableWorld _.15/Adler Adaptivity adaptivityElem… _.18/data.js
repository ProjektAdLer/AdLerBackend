var data_file_1 = {
    "name": "adaptivityElement",
    "intro": "Description: Goals: ",
    "completion": "Not completed"
}