var data_file_16 = {
    "tokens": [
        {
            "external_service": "Moodle mobile web service",
            "token": "Not exported for security reasons",
            "private_token": "Not exported for security reasons",
            "ip_restriction": null,
            "valid_until": "Tuesday, 10 June 2025, 4:49 PM",
            "created_on": "Tuesday, 18 March 2025, 3:49 PM",
            "last_access": "Tuesday, 18 March 2025, 3:49 PM",
            "name": "Webservice-XGKGO"
        },
        {
            "external_service": "adler_services",
            "token": "Not exported for security reasons",
            "private_token": "Not exported for security reasons",
            "ip_restriction": null,
            "valid_until": "Tuesday, 10 June 2025, 4:49 PM",
            "created_on": "Tuesday, 18 March 2025, 3:49 PM",
            "last_access": "Tuesday, 18 March 2025, 3:49 PM",
            "name": "Webservice-D1omz"
        }
    ]
}